#Crear 2 variables una pais y otra continente 
# Mostrar su valor en pantalla
#Poner un comentario para poner el tipo de dato

pais="Sudafrica"
continente="Africano"

print("El pais de "+pais+" se encuentra en el continente "+continente+"")

#Tipo de dato de la variable
#print(type(pais))
#print(type(continente))