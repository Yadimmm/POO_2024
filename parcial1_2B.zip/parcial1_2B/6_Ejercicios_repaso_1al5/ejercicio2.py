#Crear un script que muestre en pantalla todos los numeros
# pares del 1 al 20 
num=0
for num in range(1,21):
    if num % 2==0:
        print(num)
    