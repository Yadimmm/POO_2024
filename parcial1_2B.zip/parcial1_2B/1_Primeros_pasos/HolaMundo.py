#Crear un comentario de una linea

resultado=3+7

print("Hola mundo")
print('Hola mundo')

a=30

c=3+a
print(c)