#Utilizar la entrada y salida de datos en python

nombre=input("Ingresa el Nombre completo del alumno: ")
edad=input("Edad: ")
estatura=input("Estatura: ")

print(f"\t .:::: DATOS DEL ALUMNO ::::. \n Alumno: {nombre}\n Edad: {edad}\n Estatura: {estatura}")