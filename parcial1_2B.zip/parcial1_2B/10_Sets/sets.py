"""

 
 Sets.- 
  Es un tipo de datos para tener una coleccion de valores pero no tiene ni indice ni orden

  Set es una colección desordenada, inmutable* y no indexada. No hay miembros duplicados.
"""

personas={"Ramiro","Choche","Lupe"}

print(personas)

personas.add("Carlos") #Se agrega con el orden que el set quiere.
print(personas)

personas.remove("Lupe")
print(personas)



