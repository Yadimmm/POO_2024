#Las variables son debilmente tipadas
#es decir no es necesario indicar el tipo de
#dato al momento de utilizarlas

#Variables
edad=30
estatura=1.80
email="Yadier472@gmail.com"
logica=True
caracter='@'

#Imprimir contenido de las variables
print(edad)
print(estatura)
print(email)
print(logica)
print(caracter)

#conocer el tipo de dato que python asigno
print(type(edad))
print(type(estatura))
print(type(email))
print(type(email))
print(type(logica))
print(type(caracter))