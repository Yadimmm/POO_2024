def borrarPantalla():
  import os  
  os.system("clear")

def esperarTecla():
  print("\n \t \tOprima cualquier tecla para continuar ...")
  input()  