from clases import *

cliente1=Clientes('Ana Torres Guzman','Col. centro 1500 nte','6181234567','1234')

empleado1=Empleados('Daniel Fuentes Loera','Fraac. Alamedas 1300 nte','6183335678',1200.90,123,'A')

cliente1.info_usuario()
empleado1.info_usuario()