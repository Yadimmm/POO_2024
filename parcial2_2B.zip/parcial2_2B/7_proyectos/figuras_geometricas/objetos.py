from clases import Rectangulo, Circulo

rectangulo1 = Rectangulo(3, 4, True, 10, 20)
print(rectangulo1.get_info())

circulo1 = Circulo(3, 3, True, 6)
print(circulo1.get_info())

